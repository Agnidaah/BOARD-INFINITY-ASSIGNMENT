const http = require("http");
var url = require("url");
http.createServer(function(request, response){
    response.writeHead(200, {"Content-Type":"text/plain"});
    if(request.method==="GET"){
        var params = url.parse(request.url,true).query;
        let date_time = new Date();
    let dat = new Number(("0" + date_time.getDate()).slice(-2));
    let mont = new Number(("0" + (date_time.getMonth() + 1)).slice(-2));
    let yea = new Number(date_time.getFullYear());
    let c=yea-new Number(params.year);
    if(!(new Number(params.month)<=mont && new Number(params.date)<=dat)){
        c-=1;
    }
    response.end("<p>Hello "+params.name+"</p>"+"\n<p>You are currently "+c+"years old</p>");}
}).listen(8080);