const http=require('http');
const fs =require('fs');
const fileContent=fs.readFileSync('vege.json');
const server =http.createServer((req,res)=>{
    res.writeHead(200,{'content-type':'text/json'});
    res.end(fileContent);
});
server.listen(8080);