const http = require("http");
var url = require("url");
http.createServer(function(request, response){
    response.writeHead(200, {"Content-Type":"text/plain"});
    if(request.method==="GET"){
        var params = url.parse(request.url,true).query;
        let c=new Number(params.radius);
        if(params.object=="sphere"){
            if(params.metric=="volume"){
                response.end("volume of sphere is "+3.14*c*c*c*4/3);
            }else{
                response.end("Surface area of sphere is "+3.14*c*c*4);
            }
        }else{
            response.end("area of circle is "+c*c*3.14);}
        }
    
}).listen(8080);