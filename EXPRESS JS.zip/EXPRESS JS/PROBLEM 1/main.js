const express = require('express')
const bodyParser = require('body-parser');
const cors = require('cors');
const fs=require('fs');
const app = express();
const port = 3000;
app.use(cors());

// Configuring body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.post('/student/add', (req, res) => {
   //req.body - write to file 
   fs.writeFile("users.json", JSON.stringify(req.body), err => {
    // Checking for errors
    if (err) {throw err;}
    res.json({
        "result": "Success"
       }
       ); // Success
});
});

app.get('/student/getDetails', (req, res) => {
    // read from file 
    fs.readFile("users.json", function(err, data) {
        // Check for errors
        if (err) throw err;
        // Converting to JSON
        const users = JSON.parse(data);
        res.send(users);// Print users 
    });
 });

app.listen(port);