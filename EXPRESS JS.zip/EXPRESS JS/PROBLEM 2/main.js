const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs=require('fs');
const app = express();
const port =3000;
app.use(cors());

// Configuring body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/student/studentsList', (req, res) => {
    res.json({
        "results": [
        "Rajesh",
        "Ramesh",
        "Sayali",
        "Sanjana"
        ]
       }
       );
 });

app.listen(port);